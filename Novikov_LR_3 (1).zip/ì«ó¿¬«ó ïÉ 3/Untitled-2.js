
var a = 0;
var b = 0;
var F = 0;
var Name = "";
var Admin= "";
var YourN = "";
var YourM = "";
var SecondN = "";
var YourA = "";

document.getElementById('btn1').addEventListener("click",BTN1)

function BTN1 (c) 
{
    a = document.getElementById('myA').value;
    b = document.getElementById('myB').value;
   
 if (a > b)
 alert (b)
 else
 alert (a)

}
document.getElementById('btn2').addEventListener("click",BTN2)

function BTN2 (c) 
{
    a = document.getElementById('myA').value;
    b = document.getElementById('myB').value;
    
 if (a < b)
 alert (b)
 else
 alert (a)

}

document.getElementById('btn3').addEventListener("click",BTN3)

function BTN3 (c) 
{
  Name = document.getElementById('myName').value;
  
 
   var Admin = Name

   alert(Admin)
  
}

document.getElementById('btn4').addEventListener("click",BTN4)

function BTN4 (c) 
{
    F = document.getElementById('myV').value;
  
    var result = confirm("Этот возраст ваш?")
    if (result ==true) 
    alert (F)
   
    else
    alert("Введите заново")
    
    return false;
    
   


}

document.getElementById('btn5').addEventListener("click",BTN5)

function BTN5 (c) 
{
  YourN = document.getElementById('myYN').value;
  SecondN = document.getElementById('myYSN').value;
  YourA = document.getElementById('myYA').value;
  YourM = document.getElementById('myYM').value;
  
    
  alert (YourN)
  alert (SecondN)
  alert (YourA)
  alert (YourM)
  
}

document.getElementById('btn9').addEventListener("click",BTN9)

function BTN9 (c) 
{
  YourN = document.getElementById('myYN').value;
  SecondN = document.getElementById('myYSN').value;

  
  alert (YourN)
  
}

function ch1()
{
    var checkbox=document.getElementById('che1');
  if(checkbox.checked!=false)
  alert("Галочка поставлена");
  
  else
  alert("Галочка не поставлена");
    
}

